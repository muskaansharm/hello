# prime.py
"""
prime.py -- Write the application code here
"""

def input(str):
   return "Not an integer! Try again."
