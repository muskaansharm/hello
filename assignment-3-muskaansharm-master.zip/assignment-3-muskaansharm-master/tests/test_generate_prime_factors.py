# pylint: disable=missing-docstring

"""
The test module for Prime Factors
"""
# Python program to print prime factors
import prime #imports the prime module (prime.py)

def test_generate_prime_factor():
 assert except.ValueError(message) == "Not an integer! Try again.""
